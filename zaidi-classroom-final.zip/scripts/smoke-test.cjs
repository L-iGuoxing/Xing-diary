const assert = require("assert");
const { createPptx, generateLesson } = require("../server.cjs");

async function main() {
  const response = await generateLesson({
    forceOffline: true,
    courseType: "兴趣课",
    grade: "三到五年级",
    topic: "小小建筑师",
    durationMinutes: 45,
    studentCount: "25人左右",
    devices: ["黑板", "粉笔", "手机"],
    materials: ["纸", "铅笔", "尺子", "树枝", "石子", "绳子"],
    localContext: "学校附近有操场、菜地、小路和村庄建筑。",
    goal: "开眼界、动手做、表达分享、团队合作。"
  });

  assert.equal(response.source, "offline");
  assert.ok(response.lesson.title.includes("小小建筑师"));
  assert.ok(Array.isArray(response.lesson.flow));
  assert.ok(response.lesson.flow.length >= 4);
  assert.ok(Array.isArray(response.lesson.pptOutline));
  assert.ok(response.lesson.pptOutline.length >= 4);

  const buffer = await createPptx(response.lesson);
  assert.ok(Buffer.isBuffer(buffer));
  assert.ok(buffer.length > 1000);
  assert.equal(buffer.slice(0, 2).toString("utf8"), "PK");

  console.log("smoke-test passed");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
