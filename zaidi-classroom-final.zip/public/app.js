const form = document.getElementById("lessonForm");
const resultPanel = document.getElementById("resultPanel");
const historyList = document.getElementById("historyList");
const generateBtn = document.getElementById("generateBtn");
const offlineBtn = document.getElementById("offlineBtn");
const fillDemoBtn = document.getElementById("fillDemoBtn");
const clearHistoryBtn = document.getElementById("clearHistoryBtn");
const apiStatus = document.getElementById("apiStatus");
const statusDot = document.getElementById("statusDot");
const apiKeyBtn = document.getElementById("apiKeyBtn");
const apiKeyModal = document.getElementById("apiKeyModal");
const apiKeyInput = document.getElementById("apiKeyInput");
const apiKeySaveBtn = document.getElementById("apiKeySaveBtn");
const apiKeyClearBtn = document.getElementById("apiKeyClearBtn");
const apiKeyCloseBtn = document.getElementById("apiKeyCloseBtn");

const STORAGE_KEY = "zaidi-classroom-lessons-v2";
const API_KEY_STORAGE = "zaidi-user-api-key";

let currentLesson = null;
let currentSource = null;
let currentEditedMarkdown = "";
let selectedPptTemplate = "";
let pptTemplates = [];

init();

function init() {
  form.addEventListener("submit", handleGenerate);
  offlineBtn.addEventListener("click", handleOfflineGenerate);
  fillDemoBtn.addEventListener("click", fillDemo);
  clearHistoryBtn.addEventListener("click", clearHistory);
  apiKeyBtn.addEventListener("click", openApiKeyModal);
  apiKeySaveBtn.addEventListener("click", saveApiKey);
  apiKeyClearBtn.addEventListener("click", clearApiKey);
  apiKeyCloseBtn.addEventListener("click", closeApiKeyModal);
  apiKeyModal.addEventListener("click", (e) => { if (e.target === apiKeyModal) closeApiKeyModal(); });
  updateApiKeyBtnLabel();
  renderHistory();
  loadStatus();
  loadTemplates();
}

function getUserApiKey() {
  return localStorage.getItem(API_KEY_STORAGE) || "";
}

function openApiKeyModal() {
  apiKeyInput.value = getUserApiKey();
  apiKeyModal.style.display = "flex";
  apiKeyInput.focus();
}

function closeApiKeyModal() {
  apiKeyModal.style.display = "none";
}

function saveApiKey() {
  const key = apiKeyInput.value.trim();
  if (key) {
    localStorage.setItem(API_KEY_STORAGE, key);
  } else {
    localStorage.removeItem(API_KEY_STORAGE);
  }
  updateApiKeyBtnLabel();
  closeApiKeyModal();
  loadStatus();
}

function clearApiKey() {
  localStorage.removeItem(API_KEY_STORAGE);
  apiKeyInput.value = "";
  updateApiKeyBtnLabel();
  closeApiKeyModal();
  loadStatus();
}

function updateApiKeyBtnLabel() {
  const key = getUserApiKey();
  apiKeyBtn.textContent = key ? "⚙ API Key 已设置" : "⚙ 设置 API Key";
  apiKeyBtn.style.color = key ? "var(--color-success, #2d7a3a)" : "";
}

async function loadStatus() {
  try {
    const status = await fetchJson("/api/status");
    statusDot.className = `status-dot ${status.apiConfigured ? "ready" : "offline"}`;
    apiStatus.textContent = status.apiConfigured ? `DeepSeek ${status.model}` : "离线模板可用";
  } catch (_) {
    statusDot.className = "status-dot offline";
    apiStatus.textContent = "前端离线模式";
  }
}

async function loadTemplates() {
  try {
    const data = await fetchJson("/api/templates");
    pptTemplates = data.templates || [];
    if (!selectedPptTemplate && pptTemplates.length) selectedPptTemplate = pptTemplates[0].id;
  } catch (_) {
    pptTemplates = [];
  }
}

async function handleGenerate(event) {
  event.preventDefault();
  await generateLesson(collectForm());
}

function handleOfflineGenerate() {
  const input = collectForm();
  currentLesson = buildBrowserFallbackLesson(input);
  currentSource = "offline";
  currentEditedMarkdown = lessonToMarkdown(currentLesson);
  renderLesson({
    source: "offline",
    reason: "已使用浏览器本地模板。网络或服务不可用时，仍可保留基础备课流程。",
    lesson: currentLesson
  });
}

async function generateLesson(input) {
  setLoading(true, "生成中");
  try {
    const payload = await fetchJson("/api/generate", {
      method: "POST",
      body: JSON.stringify(input)
    });
    currentLesson = payload.lesson;
    currentSource = payload.source || "offline";
    currentEditedMarkdown = lessonToMarkdown(currentLesson);
    renderLesson(payload);
  } catch (error) {
    currentLesson = buildBrowserFallbackLesson(input);
    currentSource = "offline";
    currentEditedMarkdown = lessonToMarkdown(currentLesson);
    renderLesson({
      source: "offline",
      reason: `服务暂时不可用，已切换浏览器本地模板：${error.message || "生成失败"}`,
      lesson: currentLesson
    });
  } finally {
    setLoading(false);
  }
}

function collectForm() {
  const data = new FormData(form);
  return {
    courseType: data.get("courseType"),
    grade: data.get("grade").trim(),
    topic: data.get("topic").trim(),
    durationMinutes: Number(data.get("durationMinutes") || 45),
    studentCount: data.get("studentCount").trim(),
    subjectBlend: data.get("subjectBlend").trim(),
    devices: selectedChips("devices"),
    materials: splitItems(data.get("materials")),
    localContext: data.get("localContext").trim(),
    goal: data.get("goal").trim(),
    constraints: data.get("constraints").trim()
  };
}

function selectedChips(groupName) {
  return Array.from(document.querySelectorAll(`[data-checkbox-group="${groupName}"] input:checked`)).map((input) => input.value);
}

function splitItems(value) {
  return String(value || "")
    .split(/[，,、\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function fillDemo() {
  setRadio("courseType", "兴趣课");
  setField("grade", "三到五年级");
  setField("topic", "小小建筑师");
  setField("durationMinutes", "45");
  setField("studentCount", "25人左右");
  setField("subjectBlend", "科学、数学、艺术、职业启蒙");
  setField("materials", "纸、铅笔、尺子、树枝、石子、绳子");
  setField("localContext", "学校附近有操场、菜地、小路和村庄建筑，课堂没有稳定投影，适合用黑板和小组活动。");
  setField("goal", "开眼界、动手做、表达分享、团队合作，让孩子了解建筑师如何解决真实问题。");
  setField("constraints", "低成本、少设备、可打印，先由老师审核后使用。");
}

function setField(name, value) {
  const node = form.elements[name];
  if (node) node.value = value;
}

function setRadio(name, value) {
  const node = form.querySelector(`input[name="${name}"][value="${value}"]`);
  if (node) node.checked = true;
}

function renderLesson(payload) {
  const lesson = payload.lesson;
  const isOffline = payload.source === "offline";
  resultPanel.innerHTML = "";

  const root = document.createElement("div");
  root.className = "lesson-view";
  root.innerHTML = `
    <header class="lesson-header">
      <span class="source-pill ${isOffline ? "offline" : ""}">${isOffline ? "离线兜底" : "DeepSeek 生成"}</span>
      <h2>${escapeHtml(lesson.title)}</h2>
      <div class="lesson-meta">
        <span>${escapeHtml(lesson.courseType || "兴趣课")}</span>
        <span>${escapeHtml(lesson.ageGroup || "")}</span>
        <span>${escapeHtml(String(lesson.durationMinutes || 45))} 分钟</span>
      </div>
      <p class="hook">${escapeHtml(lesson.localHook || "")}</p>
      ${payload.reason ? `<div class="notice">${escapeHtml(payload.reason)}</div>` : ""}
      <div class="result-actions">
        <button class="primary-button" type="button" data-action="save">保存到历史</button>
        <button class="secondary-button" type="button" data-action="downloadDoc">下载教案</button>
        <button class="ghost-button" type="button" data-action="print">打印</button>
        <button class="ghost-button" type="button" data-action="markdown">复制文档</button>
      </div>
    </header>

    <section class="tool-panel">
      <div class="tool-card editor-card">
        <div class="tool-card-head">
          <div>
            <h3>在线编辑文档</h3>
            <p>老师可以直接修改教案文本，保存后会进入历史课包。</p>
          </div>
          <button class="ghost-button compact" type="button" data-action="restoreDoc">还原生成稿</button>
        </div>
        <textarea id="docEditor" class="doc-editor" spellcheck="false">${escapeHtml(currentEditedMarkdown || lessonToMarkdown(lesson))}</textarea>
      </div>

      <div class="tool-card">
        <h3>让 AI 按意见修改</h3>
        <p>例如：把活动难度降低；增加无投影版本；减少讲授，增加小组展示。</p>
        <textarea id="revisionInput" class="mini-editor" rows="4" placeholder="输入修改意见"></textarea>
        <div class="action-row">
          <button class="secondary-button" type="button" data-action="revise">AI 修改教案</button>
          <span class="inline-status" id="revisionStatus"></span>
        </div>
      </div>

      <div class="tool-card">
        <h3>课后反馈</h3>
        <p>课后记录真实课堂情况，方便下一次迭代和志愿者接力。</p>
        <div class="feedback-grid">
          <label class="field compact-field">
            <span>参与状态</span>
            <select id="feedbackEngagement">
              <option>整体积极</option>
              <option>前半段积极，后半段分散</option>
              <option>需要更多分组支持</option>
            </select>
          </label>
          <label class="field compact-field">
            <span>实际时长</span>
            <input id="feedbackDuration" value="${escapeHtml(String(lesson.durationMinutes || 45))} 分钟" />
          </label>
        </div>
        <textarea id="feedbackWorked" class="mini-editor" rows="2" placeholder="哪些环节有效？"></textarea>
        <textarea id="feedbackProblems" class="mini-editor" rows="2" placeholder="遇到了什么问题？"></textarea>
        <textarea id="feedbackNext" class="mini-editor" rows="2" placeholder="下次如何调整？"></textarea>
        <button class="ghost-button" type="button" data-action="feedback">生成反馈记录</button>
      </div>

      <div class="tool-card">
        <h3>PPT 模板库</h3>
        <p>先选择一个模板，导出 PPT 时会自动套用；也可以单独下载样张。</p>
        <div class="template-grid">
          ${renderTemplateOptions()}
        </div>
        <div class="action-row">
          <button class="secondary-button" type="button" data-action="pptx">按所选模板生成 PPT</button>
        </div>
      </div>
    </section>

    <div class="result-grid">
      ${renderListSection("课堂目标", lesson.objectives)}
      ${renderFlow(lesson.flow)}
      ${renderMaterials(lesson.materials)}
      ${renderActivities(lesson.activities)}
      <div class="two-col">
        ${renderListSection("老师提醒", lesson.teacherNotes)}
        ${renderListSection("课前准备", lesson.preparation)}
      </div>
      ${renderTaskCards(lesson.studentTaskCards)}
      ${renderPptOutline(lesson.pptOutline)}
      <div class="two-col">
        ${renderListSection("黑板方案", lesson.blackboardPlan)}
        ${renderWorksheet(lesson.worksheet)}
      </div>
      ${renderSeries(lesson.seriesPlan)}
      ${renderFeedback(lesson.feedback)}
      ${renderListSection("隐私与安全", lesson.privacyAndSafety)}
    </div>
  `;

  bindLessonActions(root, lesson);
  resultPanel.appendChild(root);
}

function bindLessonActions(root, lesson) {
  root.querySelector('[data-action="save"]').addEventListener("click", saveCurrentLesson);
  root.querySelector('[data-action="downloadDoc"]').addEventListener("click", downloadCurrentLesson);
  root.querySelector('[data-action="pptx"]').addEventListener("click", exportPptx);
  root.querySelector('[data-action="print"]').addEventListener("click", () => window.print());
  root.querySelector('[data-action="markdown"]').addEventListener("click", copyMarkdown);
  root.querySelector('[data-action="restoreDoc"]').addEventListener("click", () => {
    currentEditedMarkdown = lessonToMarkdown(currentLesson);
    root.querySelector("#docEditor").value = currentEditedMarkdown;
  });
  root.querySelector('[data-action="revise"]').addEventListener("click", reviseWithAi);
  root.querySelector('[data-action="feedback"]').addEventListener("click", createFeedback);
  root.querySelector("#docEditor").addEventListener("input", (event) => {
    currentEditedMarkdown = event.target.value;
  });
  root.querySelectorAll("[data-template]").forEach((button) => {
    button.addEventListener("click", () => selectPptTemplate(button.dataset.template, root));
  });
  root.querySelectorAll("[data-download-template]").forEach((button) => {
    button.addEventListener("click", () => downloadTemplate(button.dataset.downloadTemplate));
  });
}

function renderTemplateOptions() {
  if (!pptTemplates.length) {
    return `<div class="notice">未找到 PPT 模板文件。请把 .pptx 模板放在比赛文件夹根目录。</div>`;
  }
  if (!selectedPptTemplate) selectedPptTemplate = pptTemplates[0].id;
  return pptTemplates.map((template) => renderTemplateButton(
    template.id,
    template.name,
    `${Math.max(1, Math.round((template.size || 0) / 1024))} KB`
  )).join("");
}

function renderTemplateButton(type, title, subtitle) {
  return `
    <article class="template-card ${selectedPptTemplate === type ? "selected" : ""}">
      <button class="template-button" type="button" data-template="${escapeHtml(type)}">
        <strong>${escapeHtml(title)}</strong>
        <span>${escapeHtml(subtitle)}</span>
        <em>${selectedPptTemplate === type ? "当前套用" : "选择套用"}</em>
      </button>
      <button class="template-download" type="button" data-download-template="${escapeHtml(type)}">下载样张</button>
    </article>
  `;
}

function selectPptTemplate(type, root) {
  selectedPptTemplate = type;
  root.querySelectorAll(".template-card").forEach((card) => card.classList.remove("selected"));
  root.querySelectorAll(".template-button em").forEach((label) => {
    label.textContent = "选择套用";
  });
  const button = root.querySelector(`[data-template="${CSS.escape(type)}"]`);
  if (!button) return;
  button.closest(".template-card").classList.add("selected");
  const label = button.querySelector("em");
  if (label) label.textContent = "当前套用";
}

function renderListSection(title, items) {
  const list = asArray(items);
  if (!list.length) return "";
  return `
    <section class="lesson-section">
      <h3>${escapeHtml(title)}</h3>
      <ul class="clean-list">
        ${list.map((item) => `<li>${escapeHtml(stringifyItem(item))}</li>`).join("")}
      </ul>
    </section>
  `;
}

function renderFlow(flow) {
  const steps = asArray(flow);
  if (!steps.length) return "";
  return `
    <section class="lesson-section">
      <h3>45 分钟流程</h3>
      <div class="flow-list">
        ${steps.map((step) => `
          <article class="flow-step">
            <div class="flow-time">${escapeHtml(step.minutes || "")}</div>
            <div>
              <h4>${escapeHtml(step.stage || "课堂环节")}</h4>
              <p><strong>老师：</strong>${escapeHtml(step.teacherAction || "")}</p>
              <p><strong>学生：</strong>${escapeHtml(step.studentAction || "")}</p>
              <p><strong>呈现：</strong>${escapeHtml(step.boardOrPpt || "")}</p>
              <p><strong>提示：</strong>${escapeHtml(step.aiTip || "")}</p>
            </div>
          </article>
        `).join("")}
      </div>
    </section>
  `;
}

function renderMaterials(materials) {
  const list = asArray(materials);
  if (!list.length) return "";
  return `
    <section class="lesson-section">
      <h3>材料与替代</h3>
      <div class="material-grid">
        ${list.map((item) => `
          <div class="material-item">
            <strong>${escapeHtml(item.name || stringifyItem(item))}${item.required ? " *" : ""}</strong>
            <span>${escapeHtml(item.purpose || "")}</span>
            <span>替代：${escapeHtml(asArray(item.substitutes).join("、") || "本地可获得材料")}</span>
          </div>
        `).join("")}
      </div>
    </section>
  `;
}

function renderActivities(activities) {
  const list = asArray(activities);
  if (!list.length) return "";
  return `
    <section class="lesson-section">
      <h3>核心活动</h3>
      ${list.map((activity) => `
        <article class="activity-block">
          <h4>${escapeHtml(activity.name || "课堂活动")}</h4>
          <p><strong>目标：</strong>${escapeHtml(activity.goal || "")}</p>
          <p><strong>分组：</strong>${escapeHtml(activity.grouping || "")}</p>
          <ul class="clean-list">
            ${asArray(activity.steps).map((step) => `<li>${escapeHtml(step)}</li>`).join("")}
          </ul>
          <p><strong>低资源版：</strong>${escapeHtml(activity.lowResourceVariant || "")}</p>
          <p><strong>安全：</strong>${escapeHtml(activity.safety || "")}</p>
        </article>
      `).join("")}
    </section>
  `;
}

function renderTaskCards(cards) {
  const list = asArray(cards);
  if (!list.length) return "";
  return `
    <section class="lesson-section">
      <h3>学生任务卡</h3>
      <div class="two-col">
        ${list.map((card) => `
          <article class="activity-block">
            <h4>${escapeHtml(card.title || "任务卡")}</h4>
            <p>${escapeHtml(card.instruction || "")}</p>
            <p><strong>分享：</strong>${escapeHtml(card.sharePrompt || "")}</p>
          </article>
        `).join("")}
      </div>
    </section>
  `;
}

function renderPptOutline(slides) {
  const list = asArray(slides);
  if (!list.length) return "";
  return `
    <section class="lesson-section">
      <h3>PPT 大纲</h3>
      <div class="flow-list">
        ${list.map((slide, index) => `
          <article class="ppt-slide">
            <h4>${index + 1}. ${escapeHtml(slide.title || "幻灯片")}</h4>
            <ul class="clean-list">
              ${asArray(slide.bullets).map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
            </ul>
            <p><strong>画面：</strong>${escapeHtml(slide.visualSuggestion || "")}</p>
          </article>
        `).join("")}
      </div>
    </section>
  `;
}

function renderWorksheet(items) {
  const list = asArray(items);
  if (!list.length) return "";
  return `
    <section class="lesson-section">
      <h3>随堂练习</h3>
      <ul class="clean-list">
        ${list.map((item) => `<li>${escapeHtml(item.question || stringifyItem(item))}<br><small>${escapeHtml(item.answerHint || "")}</small></li>`).join("")}
      </ul>
    </section>
  `;
}

function renderSeries(items) {
  const list = asArray(items);
  if (!list.length) return "";
  return `
    <section class="lesson-section">
      <h3>系列课建议</h3>
      <div class="flow-list">
        ${list.map((item, index) => `
          <article class="flow-step">
            <div class="flow-time">第 ${index + 1} 课</div>
            <div>
              <h4>${escapeHtml(item.lessonTitle || "兴趣课")}</h4>
              <p><strong>重点：</strong>${escapeHtml(item.focus || "")}</p>
              <p><strong>活动：</strong>${escapeHtml(item.activity || "")}</p>
            </div>
          </article>
        `).join("")}
      </div>
    </section>
  `;
}

function renderFeedback(feedback) {
  if (!feedback) return "";
  return `
    <section class="lesson-section">
      <h3>课后反馈记录</h3>
      <ul class="clean-list">
        <li>参与状态：${escapeHtml(feedback.engagement || "")}</li>
        <li>实际时长：${escapeHtml(feedback.duration || "")}</li>
        <li>有效环节：${escapeHtml(feedback.worked || "")}</li>
        <li>问题记录：${escapeHtml(feedback.problems || "")}</li>
        <li>下次调整：${escapeHtml(feedback.next || "")}</li>
      </ul>
    </section>
  `;
}

async function reviseWithAi() {
  if (!currentLesson) return;
  const instruction = document.getElementById("revisionInput").value.trim();
  const status = document.getElementById("revisionStatus");
  if (!instruction) {
    status.textContent = "请先填写修改意见";
    return;
  }
  status.textContent = "修改中";
  try {
    const payload = await fetchJson("/api/revise", {
      method: "POST",
      body: JSON.stringify({
        lesson: currentLesson,
        instruction,
        input: collectForm()
      })
    });
    currentLesson = payload.lesson;
    currentSource = payload.source || currentSource;
    currentEditedMarkdown = lessonToMarkdown(currentLesson);
    renderLesson(payload);
  } catch (error) {
    status.textContent = `修改失败：${error.message || "未知错误"}`;
  }
}

function createFeedback() {
  if (!currentLesson) return;
  currentLesson.feedback = {
    engagement: document.getElementById("feedbackEngagement").value,
    duration: document.getElementById("feedbackDuration").value.trim(),
    worked: document.getElementById("feedbackWorked").value.trim() || "待补充",
    problems: document.getElementById("feedbackProblems").value.trim() || "待补充",
    next: document.getElementById("feedbackNext").value.trim() || "待补充",
    createdAt: new Date().toISOString()
  };
  currentEditedMarkdown = lessonToMarkdown(currentLesson);
  renderLesson({ lesson: currentLesson, source: currentSource || "offline", reason: "课后反馈已写入课包。" });
}

async function downloadTemplate(type) {
  try {
    const response = await fetch(`/api/export/template?type=${encodeURIComponent(type)}`);
    if (!response.ok) throw new Error(await response.text());
    const blob = await response.blob();
    triggerDownload(blob, `zaidi-template-${type}.pptx`);
  } catch (error) {
    renderError(`模板下载失败：${error.message || "未知错误"}`, true);
  }
}

function saveCurrentLesson() {
  if (!currentLesson) return;
  syncEditorMarkdown();
  const history = readHistory();
  const record = {
    id: `${Date.now()}`,
    createdAt: new Date().toISOString(),
    source: currentSource,
    lesson: currentLesson,
    markdown: currentEditedMarkdown
  };
  history.unshift(record);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(0, 12)));
  renderHistory();
}

function downloadCurrentLesson() {
  if (!currentLesson) return;
  syncEditorMarkdown();
  const markdown = currentEditedMarkdown || lessonToMarkdown(currentLesson);
  const title = currentLesson.title || "兴趣课教案";
  const filename = `${sanitizeFilename(title)}-${formatDateForFilename(new Date())}.md`;
  triggerDownload(new Blob([markdown], { type: "text/markdown;charset=utf-8" }), filename);
}

function readHistory() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch (_) {
    return [];
  }
}

function renderHistory() {
  const history = readHistory();
  if (!history.length) {
    historyList.innerHTML = `<div class="notice">还没有保存的课包。</div>`;
    return;
  }
  historyList.innerHTML = history.map((record) => `
    <button class="history-item" type="button" data-id="${escapeHtml(record.id)}">
      <strong>${escapeHtml(record.lesson.title || "未命名课包")}</strong>
      <span>${formatTime(record.createdAt)} · ${record.source === "deepseek" ? "AI" : "离线"}</span>
    </button>
  `).join("");
  historyList.querySelectorAll(".history-item").forEach((button) => {
    button.addEventListener("click", () => {
      const record = readHistory().find((item) => item.id === button.dataset.id);
      if (!record) return;
      currentLesson = record.lesson;
      currentSource = record.source;
      currentEditedMarkdown = record.markdown || lessonToMarkdown(record.lesson);
      renderLesson({ lesson: record.lesson, source: record.source });
    });
  });
}

function clearHistory() {
  localStorage.removeItem(STORAGE_KEY);
  renderHistory();
}

async function exportPptx() {
  if (!currentLesson) return;
  setExporting(true);
  try {
    const response = await fetch("/api/export/pptx", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lesson: currentLesson, template: selectedPptTemplate })
    });
    if (!response.ok) throw new Error(await response.text());
    const blob = await response.blob();
    triggerDownload(blob, `zaidi-lesson-${Date.now()}.pptx`);
  } catch (error) {
    renderError(`PPT 导出失败：${error.message || "未知错误"}`, true);
  } finally {
    setExporting(false);
  }
}

async function copyMarkdown() {
  syncEditorMarkdown();
  await navigator.clipboard.writeText(currentEditedMarkdown || lessonToMarkdown(currentLesson));
}

function syncEditorMarkdown() {
  const editor = document.getElementById("docEditor");
  if (editor) currentEditedMarkdown = editor.value;
}

function triggerDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function sanitizeFilename(value) {
  return String(value || "兴趣课教案")
    .replace(/[\\/:*?"<>|]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 60) || "兴趣课教案";
}

function formatDateForFilename(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}`;
}

function lessonToMarkdown(lesson) {
  if (!lesson) return "";
  const lines = [
    `# ${lesson.title || "兴趣课课包"}`,
    "",
    `- 类型：${lesson.courseType || ""}`,
    `- 年级：${lesson.ageGroup || ""}`,
    `- 时长：${lesson.durationMinutes || 45} 分钟`,
    "",
    `> ${lesson.localHook || ""}`
  ];
  pushList(lines, "课堂目标", lesson.objectives);
  pushFlow(lines, lesson.flow);
  pushList(lines, "材料与替代", asArray(lesson.materials).map((item) => `${item.name || stringifyItem(item)}：${item.purpose || ""}`));
  pushList(lines, "老师提醒", lesson.teacherNotes);
  pushList(lines, "课前准备", lesson.preparation);
  pushList(lines, "黑板方案", lesson.blackboardPlan);
  pushList(lines, "隐私与安全", lesson.privacyAndSafety);
  if (lesson.feedback) {
    lines.push("", "## 课后反馈");
    lines.push(`- 参与状态：${lesson.feedback.engagement || ""}`);
    lines.push(`- 实际时长：${lesson.feedback.duration || ""}`);
    lines.push(`- 有效环节：${lesson.feedback.worked || ""}`);
    lines.push(`- 问题记录：${lesson.feedback.problems || ""}`);
    lines.push(`- 下次调整：${lesson.feedback.next || ""}`);
  }
  return lines.join("\n");
}

function pushList(lines, title, items) {
  const list = asArray(items);
  if (!list.length) return;
  lines.push("", `## ${title}`);
  list.forEach((item) => lines.push(`- ${stringifyItem(item)}`));
}

function pushFlow(lines, flow) {
  const list = asArray(flow);
  if (!list.length) return;
  lines.push("", "## 课堂流程");
  list.forEach((step) => {
    lines.push(`- ${step.minutes || ""} ${step.stage || ""}：${step.teacherAction || ""}`);
  });
}

function buildBrowserFallbackLesson(input) {
  const materials = input.materials && input.materials.length ? input.materials : ["纸", "铅笔", "树枝", "石子", "绳子"];
  return {
    title: `${input.topic || "兴趣探索"}：用身边材料打开一节兴趣课`,
    courseType: input.courseType || "兴趣课",
    durationMinutes: input.durationMinutes || 45,
    ageGroup: input.grade || "三到五年级",
    localHook: `从${input.localContext || "学校附近的生活经验"}出发，把远方世界变成今天能动手完成的小挑战。`,
    objectives: [
      `认识“${input.topic || "兴趣主题"}”背后的真实世界问题。`,
      `使用${materials.slice(0, 4).join("、")}完成一次小组动手任务。`,
      "用任务卡表达自己的观察、想法和下一步兴趣。"
    ],
    teacherNotes: ["内容给孩子使用前请老师审核。", "没有投影时使用黑板方案和口头故事导入。", "不采集学生姓名、照片、家庭情况等敏感信息。"],
    materials: materials.slice(0, 8).map((name, index) => ({
      name,
      purpose: index < 4 ? "小组动手材料" : "展示或补充材料",
      substitutes: ["纸", "粉笔", "本地可获得材料"],
      required: index < 3
    })),
    preparation: ["按小组分发材料。", "黑板写好今日问题、小组任务和展示句式。", "准备作品卡和兴趣问题卡。"],
    flow: [
      { minutes: "0-5", stage: "在地导入", teacherAction: `用当地场景提问：它和“${input.topic || "今天的主题"}”有什么关系？`, studentAction: "分享自己见过的类似事物。", boardOrPpt: "今日问题", aiTip: "先接住孩子熟悉的经验。" },
      { minutes: "5-12", stage: "远方故事", teacherAction: "讲一个真实世界里的职业或科学故事。", studentAction: "找出问题、工具和办法。", boardOrPpt: "问题 / 工具 / 办法", aiTip: "用平等探索的语气。" },
      { minutes: "12-30", stage: "小组动手", teacherAction: "发放材料，巡回提问和提醒安全。", studentAction: `用${materials.slice(0, 4).join("、")}完成模型、草图或方案。`, boardOrPpt: "小组任务", aiTip: "材料不足时允许画图替代。" },
      { minutes: "30-40", stage: "展示互评", teacherAction: "邀请小组展示，引导同学给出建议。", studentAction: "说明用途、问题和改进点。", boardOrPpt: "我发现 / 我喜欢 / 我建议", aiTip: "不做排名。" },
      { minutes: "40-45", stage: "兴趣收束", teacherAction: "收集匿名兴趣问题。", studentAction: "写下或画出一个还想知道的问题。", boardOrPpt: "我还想知道……", aiTip: "用小组编号即可。" }
    ],
    activities: [
      { name: `身边材料挑战：做一个“${input.topic || "兴趣主题"}”`, goal: "把兴趣主题变成可触摸的小作品。", grouping: "4-6 人一组。", steps: ["画草图", "选材料", "动手制作", "展示介绍"], lowResourceVariant: "没有材料时改成黑板共创图。", safety: "不用尖锐工具，不追逐打闹。" }
    ],
    studentTaskCards: [
      { title: "我的兴趣发现卡", instruction: "画出今天的作品，标出最重要的部分。", sharePrompt: "我最想继续了解的是……" }
    ],
    pptOutline: [
      { title: input.topic || "兴趣探索", bullets: [input.grade || "三到五年级", `材料：${materials.slice(0, 4).join("、")}`, "先观察，再动手，再分享"], speakerNotes: "封面页。", visualSuggestion: "本地场景照片或黑板手绘图" },
      { title: "今天的问题", bullets: ["它和我们身边有什么关系？", "我们能做出一个小模型吗？"], speakerNotes: "让孩子先说经验。", visualSuggestion: "问题卡" },
      { title: "小组挑战", bullets: ["选材料", "画草图", "动手做", "准备一句介绍"], speakerNotes: "强调安全和合作。", visualSuggestion: "步骤图" }
    ],
    blackboardPlan: [`标题：${input.topic || "兴趣探索"}`, "今日问题：身边哪里能看到它？", "三列：问题 / 工具 / 办法"],
    worksheet: [{ question: "画出你的小组作品，并标出最重要的部分。", answerHint: "能说明用途即可。" }],
    seriesPlan: [{ lessonTitle: "入门：我见过什么", focus: "连接本地经验", activity: "观察与故事导入" }],
    privacyAndSafety: ["不记录学生真实姓名、照片、家庭情况或成绩。", "AI 内容只给老师审核，不直接给孩子自由使用。", "不设置积分排名和持续奖励循环。"]
  };
}

function setLoading(loading, label) {
  generateBtn.disabled = loading;
  offlineBtn.disabled = loading;
  generateBtn.textContent = loading ? label : "生成课包";
}

function setExporting(exporting) {
  const button = resultPanel.querySelector('[data-action="pptx"]');
  if (!button) return;
  button.disabled = exporting;
  button.textContent = exporting ? "导出中" : "导出 PPT";
}

function renderError(message, append) {
  const html = `<div class="notice">${escapeHtml(message)}</div>`;
  if (append) resultPanel.insertAdjacentHTML("afterbegin", html);
  else resultPanel.innerHTML = html;
}

async function fetchJson(url, options = {}) {
  const userKey = getUserApiKey();
  const extraHeaders = userKey ? { "x-user-api-key": userKey } : {};
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json", ...extraHeaders, ...(options.headers || {}) },
    ...options
  });
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}

function asArray(value) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

function stringifyItem(item) {
  if (item === null || item === undefined) return "";
  if (typeof item === "string") return item;
  if (typeof item === "number") return String(item);
  if (item.text) return item.text;
  if (item.question) return `${item.question} ${item.answerHint || ""}`;
  if (item.title && item.instruction) return `${item.title}：${item.instruction}`;
  return Object.values(item).flat().join(" ");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatTime(value) {
  const date = new Date(value);
  return date.toLocaleString("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}
