const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const zlib = require("zlib");
const { URL } = require("url");

const ROOT = process.env.ZAIDI_ROOT || __dirname;
const PUBLIC_DIR = path.join(ROOT, "public");

loadEnvFile(path.join(ROOT, ".env"));
loadEnvFile(path.join(ROOT, ".env.local"));

const PORT = Number(process.env.PORT || 4173);
const DEEPSEEK_BASE_URL = process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com";
const DEEPSEEK_MODEL = process.env.DEEPSEEK_MODEL || "deepseek-v4-flash";
const DEEPSEEK_TIMEOUT_MS = Number(process.env.DEEPSEEK_TIMEOUT_MS || 90000);

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml; charset=utf-8"
};

const server = http.createServer(async (req, res) => {
  try {
    const requestUrl = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === "POST" && requestUrl.pathname === "/api/generate") {
      const input = await readJson(req);
      const userKey = extractUserKey(req);
      const result = await generateLesson(input, userKey);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === "POST" && requestUrl.pathname === "/api/revise") {
      const body = await readJson(req);
      const userKey = extractUserKey(req);
      const result = await reviseLesson(body.lesson, body.instruction, body.input, userKey);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === "POST" && requestUrl.pathname === "/api/export/pptx") {
      const body = await readJson(req);
      const template = safeAscii(body.template || "exploration");
      const buffer = await createPptx(body.lesson || body, template);
      const asciiFilename = `zaidi-lesson-${Date.now()}.pptx`;
      res.writeHead(200, {
        "Content-Type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "Content-Disposition": `attachment; filename=${asciiFilename}`
      });
      res.end(buffer);
      return;
    }

    if (req.method === "GET" && requestUrl.pathname === "/api/templates") {
      sendJson(res, 200, { templates: listPptTemplates() });
      return;
    }

    if (req.method === "GET" && requestUrl.pathname === "/api/export/template") {
      const type = requestUrl.searchParams.get("type") || "exploration";
      const templatePath = resolvePptTemplatePath(type);
      if (templatePath) {
        const filename = `zaidi-template-${safeAscii(type)}.pptx`;
        res.writeHead(200, {
          "Content-Type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          "Content-Disposition": `attachment; filename=${filename}`
        });
        fs.createReadStream(templatePath).pipe(res);
        return;
      }
      const lesson = buildTemplateLesson(type);
      const buffer = await createPptx(lesson, type);
      const filename = `zaidi-template-${safeAscii(type)}.pptx`;
      res.writeHead(200, {
        "Content-Type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "Content-Disposition": `attachment; filename=${filename}`
      });
      res.end(buffer);
      return;
    }

    if (req.method === "GET" && requestUrl.pathname === "/api/status") {
      sendJson(res, 200, {
        apiConfigured: hasDeepSeekKey(),
        model: DEEPSEEK_MODEL,
        timeoutMs: DEEPSEEK_TIMEOUT_MS,
        pptxAvailable: true,
        pptxEngine: "user-template",
        templates: listPptTemplates().length
      });
      return;
    }

    serveStatic(requestUrl.pathname, res);
  } catch (error) {
    const message = error && error.message ? error.message : "Unknown error";
    sendJson(res, 500, { error: message });
  }
});

if (require.main === module) {
  startServer();
}

module.exports = {
  buildOfflineLesson,
  createPptx,
  generateLesson,
  normalizeInput,
  server,
  startServer
};

function startServer(port = PORT) {
  return server.listen(port, () => {
    console.log(`在地课堂已启动: http://localhost:${port}`);
    console.log(`DeepSeek: ${hasDeepSeekKey() ? "已配置" : "未配置，使用离线模板"}`);
  });
}

function loadEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return;
  const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const index = trimmed.indexOf("=");
    if (index === -1) continue;
    const key = trimmed.slice(0, index).trim();
    const value = trimmed.slice(index + 1).trim().replace(/^["']|["']$/g, "");
    if (key && process.env[key] === undefined) process.env[key] = value;
  }
}

function extractUserKey(req) {
  const k = req.headers["x-user-api-key"];
  return (k && k.trim() && !k.includes("your_deepseek")) ? k.trim() : null;
}

function hasDeepSeekKey(userKey) {
  const key = userKey || process.env.DEEPSEEK_API_KEY;
  return Boolean(key && key.trim() && !key.includes("your_deepseek_api_key_here"));
}

async function readJson(req) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > 2_000_000) throw new Error("请求内容过大");
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString("utf8");
  if (!raw.trim()) return {};
  return JSON.parse(raw);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function serveStatic(pathname, res) {
  const cleanPath = pathname === "/" ? "/index.html" : pathname;
  const target = path.normalize(path.join(PUBLIC_DIR, cleanPath));
  if (!target.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }
  if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
    res.writeHead(404);
    res.end("Not found");
    return;
  }
  const ext = path.extname(target).toLowerCase();
  res.writeHead(200, {
    "Content-Type": MIME_TYPES[ext] || "application/octet-stream",
    "Cache-Control": "no-store"
  });
  fs.createReadStream(target).pipe(res);
}

async function generateLesson(input, userKey) {
  const normalizedInput = normalizeInput(input);
  if (input && input.forceOffline) {
    return {
      source: "offline",
      reason: "已手动使用离线模板生成。",
      lesson: buildOfflineLesson(normalizedInput)
    };
  }

  if (!hasDeepSeekKey(userKey)) {
    return {
      source: "offline",
      reason: "未配置 DEEPSEEK_API_KEY，已使用离线模板生成。",
      lesson: buildOfflineLesson(normalizedInput)
    };
  }

  try {
    const lesson = await callDeepSeek(normalizedInput, userKey);
    return {
      source: "deepseek",
      model: DEEPSEEK_MODEL,
      lesson: normalizeLesson(lesson, normalizedInput)
    };
  } catch (error) {
    return {
      source: "offline",
      reason: `DeepSeek 调用失败，已切换离线模板：${error.message}`,
      lesson: buildOfflineLesson(normalizedInput)
    };
  }
}

async function reviseLesson(lesson, instruction, input, userKey) {
  const baseLesson = lesson && typeof lesson === "object" ? lesson : buildOfflineLesson(normalizeInput(input || {}));
  const revisionText = String(instruction || "").trim();
  if (!revisionText) {
    return {
      source: "offline",
      reason: "请先填写修改意见。",
      lesson: baseLesson
    };
  }

  if (!hasDeepSeekKey(userKey)) {
    return {
      source: "offline",
      reason: "未配置 DeepSeek，已把修改意见记录到教案中。",
      lesson: reviseOfflineLesson(baseLesson, revisionText)
    };
  }

  try {
    const revised = await callDeepSeekRevision(baseLesson, revisionText, normalizeInput(input || {}), userKey);
    return {
      source: "deepseek",
      model: DEEPSEEK_MODEL,
      lesson: normalizeLesson(revised, normalizeInput(input || {}))
    };
  } catch (error) {
    return {
      source: "offline",
      reason: `DeepSeek 修改失败，已先记录老师意见：${error.message}`,
      lesson: reviseOfflineLesson(baseLesson, revisionText)
    };
  }
}

async function callDeepSeek(input, userKey) {
  const payload = {
    model: DEEPSEEK_MODEL,
    temperature: 0.65,
    max_tokens: 6000,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content: [
          "你是“在地课堂”的 AI 课程设计助手，服务对象是支教志愿者和当地老师。",
          "你的任务是生成老师审核后使用的兴趣课或学科融合课课包，不直接面向未成年人自由对话。",
          "必须适配乡村课堂：低带宽、低成本材料、低配置设备、可打印、可无投影上课。",
          "不要采集或要求学生姓名、照片、家庭收入、健康、宗教、户籍等敏感信息。",
          "输出必须是严格 JSON，不要添加 Markdown 代码块。"
        ].join("\n")
      },
      {
        role: "user",
        content: buildPrompt(input)
      }
    ]
  };

  const response = await fetch(`${DEEPSEEK_BASE_URL.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${userKey || process.env.DEEPSEEK_API_KEY}`
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(DEEPSEEK_TIMEOUT_MS)
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 180)}`);
  }

  const data = await response.json();
  const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!content) throw new Error("模型未返回内容");
  return parseJsonContent(content);
}

async function callDeepSeekRevision(lesson, instruction, input, userKey) {
  const payload = {
    model: DEEPSEEK_MODEL,
    temperature: 0.45,
    max_tokens: 6000,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content: [
          "你是支教兴趣课教案编辑助手。",
          "请根据老师修改意见调整课包，保持原有 JSON 结构。",
          "不要删除隐私与安全提醒，不要加入需要采集学生敏感信息的内容。",
          "输出严格 JSON，不要 Markdown 代码块。"
        ].join("\n")
      },
      {
        role: "user",
        content: JSON.stringify({
          task: "根据老师意见修改现有课包",
          instruction,
          input,
          lesson
        })
      }
    ]
  };

  const response = await fetch(`${DEEPSEEK_BASE_URL.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${userKey || process.env.DEEPSEEK_API_KEY}`
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(DEEPSEEK_TIMEOUT_MS)
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 180)}`);
  }

  const data = await response.json();
  const content = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!content) throw new Error("模型未返回修改内容");
  return parseJsonContent(content);
}

function buildPrompt(input) {
  return JSON.stringify({
    task: "生成一个可直接给支教老师使用的完整兴趣课课包",
    input,
    output_schema: {
      title: "课程标题",
      courseType: "兴趣课/学科融合兴趣课/学科课",
      durationMinutes: 45,
      ageGroup: "适用年级段",
      localHook: "用当地经验导入课程的一句话",
      objectives: ["目标1", "目标2", "目标3"],
      teacherNotes: ["给老师的提醒"],
      materials: [
        {
          name: "材料名称",
          purpose: "用途",
          substitutes: ["替代材料"],
          required: true
        }
      ],
      preparation: ["课前准备"],
      flow: [
        {
          minutes: "0-5",
          stage: "环节名称",
          teacherAction: "老师做什么",
          studentAction: "学生做什么",
          boardOrPpt: "黑板或PPT呈现",
          aiTip: "支教适配提示"
        }
      ],
      activities: [
        {
          name: "活动名称",
          goal: "活动目标",
          grouping: "分组方式",
          steps: ["步骤1", "步骤2"],
          lowResourceVariant: "无投影/低材料版本",
          safety: "安全提醒"
        }
      ],
      questions: [
        {
          type: "开放提问/回顾提问/拓展提问",
          text: "问题"
        }
      ],
      studentTaskCards: [
        {
          title: "任务卡标题",
          instruction: "学生任务说明",
          sharePrompt: "展示分享提示"
        }
      ],
      assessment: ["观察评价点"],
      extension: ["课后延伸"],
      pptOutline: [
        {
          title: "幻灯片标题",
          bullets: ["要点1", "要点2"],
          speakerNotes: "讲解提示",
          visualSuggestion: "图片或板书建议"
        }
      ],
      blackboardPlan: ["板书内容"],
      worksheet: [
        {
          question: "随堂练习或反思题",
          answerHint: "答案提示"
        }
      ],
      seriesPlan: [
        {
          lessonTitle: "系列课标题",
          focus: "本节重点",
          activity: "核心活动"
        }
      ],
      privacyAndSafety: ["隐私与安全提醒"]
    },
    constraints: [
      "总环节必须适合 input.durationMinutes。",
      "优先使用 input.materials 和 input.localContext 中出现的本地材料与场景。",
      "如果 input.devices 不包含投影或电脑，PPT 大纲仍要给出，但同时提供黑板替代方案。",
      "兴趣启蒙要尊重孩子，不使用怜悯、俯视或过度城市中心的话术。",
      "内容必须先给老师审核，不设计让孩子长期沉迷的奖励循环。"
    ]
  });
}

function parseJsonContent(content) {
  try {
    return JSON.parse(content);
  } catch (_) {
    const start = content.indexOf("{");
    const end = content.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(content.slice(start, end + 1));
    }
    throw new Error("模型返回不是有效 JSON");
  }
}

function normalizeInput(input) {
  return {
    courseType: input.courseType || "兴趣课",
    grade: input.grade || "三到五年级",
    topic: input.topic || "小小建筑师",
    durationMinutes: Number(input.durationMinutes || 45),
    studentCount: input.studentCount || "25人左右",
    devices: asArray(input.devices).length ? asArray(input.devices) : ["黑板", "粉笔"],
    materials: asArray(input.materials).length ? asArray(input.materials) : ["纸", "铅笔", "树枝", "石子", "绳子"],
    localContext: input.localContext || "学校附近有操场、菜地、小路和村庄建筑。",
    goal: input.goal || "开眼界、动手做、表达分享、团队合作",
    subjectBlend: input.subjectBlend || "科学、数学、艺术",
    constraints: input.constraints || "低成本、少设备、可打印，先由老师审核后使用。"
  };
}

function normalizeLesson(lesson, input) {
  const fallback = buildOfflineLesson(input);
  return {
    ...fallback,
    ...lesson,
    title: lesson.title || fallback.title,
    objectives: asArray(lesson.objectives).length ? asArray(lesson.objectives) : fallback.objectives,
    materials: asArray(lesson.materials).length ? asArray(lesson.materials) : fallback.materials,
    flow: asArray(lesson.flow).length ? asArray(lesson.flow) : fallback.flow,
    activities: asArray(lesson.activities).length ? asArray(lesson.activities) : fallback.activities,
    pptOutline: asArray(lesson.pptOutline).length ? asArray(lesson.pptOutline) : fallback.pptOutline,
    privacyAndSafety: asArray(lesson.privacyAndSafety).length ? asArray(lesson.privacyAndSafety) : fallback.privacyAndSafety
  };
}

function buildOfflineLesson(input) {
  const topic = input.topic;
  const hasProjector = input.devices.some((item) => /投影|电脑|屏幕|电视/.test(item));
  const materials = input.materials.slice(0, 8);

  return {
    title: `${topic}：一节用身边材料打开世界的兴趣课`,
    courseType: input.courseType,
    durationMinutes: input.durationMinutes,
    ageGroup: input.grade,
    localHook: `从孩子熟悉的${pickLocalThing(input.localContext)}出发，把“远方世界”变成今天能动手做的课堂。`,
    objectives: [
      `了解“${topic}”背后的一个真实世界问题或职业场景。`,
      `使用${materials.slice(0, 3).join("、")}完成一次小组动手任务。`,
      "用一张任务卡表达自己的观察、想法和下一步兴趣。"
    ],
    teacherNotes: [
      "这份内容面向老师和志愿者，给孩子使用前请先审核。",
      "如果没有投影，直接使用黑板版流程和任务卡。",
      "不要记录学生姓名、照片或家庭情况，用小组编号即可。"
    ],
    materials: materials.map((name, index) => ({
      name,
      purpose: index < 3 ? "核心动手材料" : "辅助展示或装饰",
      substitutes: buildSubstitutes(name),
      required: index < 3
    })),
    preparation: [
      "提前把材料按小组分好，每组一份。",
      "在黑板左侧写出今日问题，右侧留给小组展示。",
      hasProjector ? "准备 6-8 页简洁 PPT，图片优先，文字少。" : "把 PPT 大纲改成黑板关键词和口头讲述。"
    ],
    flow: [
      {
        minutes: "0-5",
        stage: "在地导入",
        teacherAction: `用${pickLocalThing(input.localContext)}提问：它和“${topic}”有什么关系？`,
        studentAction: "举手说出自己见过的类似事物或经验。",
        boardOrPpt: `今日问题：我们能用身边材料做出一个“${topic}”的小模型吗？`,
        aiTip: "先接住孩子的本地经验，再引到更大的世界。"
      },
      {
        minutes: "5-12",
        stage: "远方打开",
        teacherAction: `讲一个和“${topic}”相关的真实故事，控制在 3 分钟内。`,
        studentAction: "找出故事里的“问题、工具、办法”。",
        boardOrPpt: "问题 / 工具 / 办法 三列板书。",
        aiTip: "避免城市优越感，用平等的探索语气。"
      },
      {
        minutes: "12-30",
        stage: "小组动手",
        teacherAction: "发放材料，提醒安全边界，巡回提问。",
        studentAction: `用${materials.slice(0, 4).join("、")}完成小模型或方案图。`,
        boardOrPpt: "小组任务：能说明、能展示、能改进。",
        aiTip: "材料不足时允许画图替代，不让孩子因为材料少而失败。"
      },
      {
        minutes: "30-40",
        stage: "展示互评",
        teacherAction: "邀请 2-3 组展示，用观察问题引导表达。",
        studentAction: "说出本组作品的想法、遇到的问题、想改进的地方。",
        boardOrPpt: "我发现 / 我喜欢 / 我建议。",
        aiTip: "评价重点放在表达、合作和改进，不做排名。"
      },
      {
        minutes: "40-45",
        stage: "兴趣收束",
        teacherAction: "发任务卡或口头收束，给出下一节延伸方向。",
        studentAction: "写下或说出一个还想知道的问题。",
        boardOrPpt: "我还想知道……",
        aiTip: "用匿名小组反馈即可，不收集个人敏感信息。"
      }
    ],
    activities: [
      {
        name: `身边材料挑战：做一个“${topic}”`,
        goal: "让孩子把抽象兴趣主题转化为可触摸、可讨论的作品。",
        grouping: "4-6 人一组，材料员、记录员、讲解员轮换。",
        steps: [
          "每组选 3 种材料，先画一个 1 分钟草图。",
          "用 10 分钟搭建或制作模型。",
          "给作品起名，并准备一句介绍。",
          "展示后根据同学建议改进一个地方。"
        ],
        lowResourceVariant: "没有材料时改为“黑板共创图 + 小组口头方案”。",
        safety: "不用尖锐工具；绳子、树枝等材料只做模型，不追逐打闹。"
      }
    ],
    questions: [
      { type: "开放提问", text: `如果把“${topic}”带到我们村子或学校，会先解决什么小问题？` },
      { type: "观察提问", text: "你们小组用了哪种材料？它像真实世界里的什么工具？" },
      { type: "拓展提问", text: "如果下节课还能继续，你想加一个什么新功能？" }
    ],
    studentTaskCards: [
      {
        title: "我的兴趣发现卡",
        instruction: `画出或写出你今天做的“${topic}”作品，标出一个最重要的部分。`,
        sharePrompt: "我最想继续了解的是……"
      },
      {
        title: "小组改进卡",
        instruction: "写下作品的一个优点和一个可以改进的地方。",
        sharePrompt: "我们下一次会这样改……"
      }
    ],
    assessment: [
      "是否能把本地经验和课程主题联系起来。",
      "是否参与小组分工并完成作品或方案。",
      "是否能表达一个自己的兴趣问题。"
    ],
    extension: [
      "让孩子观察家里或学校附近有没有类似结构、职业或现象。",
      "下节课可以围绕孩子提出的问题继续做系列探索。"
    ],
    pptOutline: [
      {
        title: topic,
        bullets: [`${input.grade}兴趣课`, `材料：${materials.slice(0, 4).join("、")}`, "先观察，再动手，再分享"],
        speakerNotes: "封面页，用一个本地问题开场。",
        visualSuggestion: "本地场景照片或黑板手绘图"
      },
      {
        title: "今天的问题",
        bullets: [`${topic}和我们身边有什么关系？`, "我们能做出一个小模型吗？"],
        speakerNotes: "让孩子先说身边经验。",
        visualSuggestion: "问题卡"
      },
      {
        title: "真实世界里的例子",
        bullets: ["它解决了什么问题", "它用了什么工具", "它为什么有趣"],
        speakerNotes: "讲故事，不堆知识点。",
        visualSuggestion: "示意图或关键词"
      },
      {
        title: "小组挑战",
        bullets: ["选材料", "画草图", "动手做", "准备一句介绍"],
        speakerNotes: "强调安全和合作。",
        visualSuggestion: "步骤图"
      },
      {
        title: "展示与改进",
        bullets: ["我发现", "我喜欢", "我建议"],
        speakerNotes: "不排名，用建设性评价。",
        visualSuggestion: "三列表格"
      },
      {
        title: "我还想知道",
        bullets: ["写下一个问题", "选出下一节课方向"],
        speakerNotes: "为系列兴趣课留下线索。",
        visualSuggestion: "兴趣问题墙"
      }
    ],
    blackboardPlan: [
      `标题：${topic}`,
      "今日问题：身边哪里能看到它？",
      "三列：问题 / 工具 / 办法",
      "展示句式：我们做的是……它能……我们想改进……"
    ],
    worksheet: [
      { question: `请画出你的“${topic}”作品，并标出最重要的一个部分。`, answerHint: "能说明用途即可。" },
      { question: "今天你最想继续了解的问题是什么？", answerHint: "允许画图、拼音或口头表达。" }
    ],
    seriesPlan: [
      { lessonTitle: `${topic}入门：我见过什么`, focus: "连接本地经验", activity: "观察与故事导入" },
      { lessonTitle: `${topic}动手：我能做什么`, focus: "低成本制作", activity: "材料挑战" },
      { lessonTitle: `${topic}职业：谁在做这件事`, focus: "职业启蒙", activity: "角色任务卡" },
      { lessonTitle: `${topic}表达：我的小展览`, focus: "表达与分享", activity: "小组展示会" }
    ],
    privacyAndSafety: [
      "不记录学生真实姓名、照片、家庭情况或成绩。",
      "AI 内容只给老师审核，不直接推送给孩子。",
      "活动不设置积分排名和持续奖励循环。"
    ]
  };
}

function reviseOfflineLesson(lesson, instruction) {
  const revised = JSON.parse(JSON.stringify(lesson));
  revised.teacherNotes = asArray(revised.teacherNotes);
  revised.teacherNotes.unshift(`老师修改意见：${instruction}`);
  revised.revisionLog = asArray(revised.revisionLog);
  revised.revisionLog.unshift({
    at: new Date().toISOString(),
    instruction,
    mode: "offline-record"
  });
  revised.pptOutline = asArray(revised.pptOutline);
  revised.pptOutline.push({
    title: "老师调整重点",
    bullets: [instruction, "上课前请老师再次审核活动时长、材料与安全边界。"],
    speakerNotes: "这是根据老师意见追加的调整页。",
    visualSuggestion: "审核清单"
  });
  return revised;
}

function buildTemplateLesson(type) {
  const templates = {
    exploration: {
      title: "兴趣探索课 PPT 模板：从身边问题出发",
      courseType: "兴趣课模板",
      ageGroup: "三到六年级",
      durationMinutes: 45,
      localHook: "用孩子熟悉的本地场景提出一个问题，再连接到更大的世界。",
      objectives: ["提出一个可探索的问题", "完成一次低成本动手活动", "表达一个新的兴趣方向"],
      pptOutline: [
        { title: "课程封面", bullets: ["主题名称", "年级与时长", "今日关键词"], speakerNotes: "用一个本地问题开场。", visualSuggestion: "本地照片或黑板手绘" },
        { title: "今天的问题", bullets: ["我们身边哪里能看到它？", "它解决了什么问题？", "我们能动手做什么？"], speakerNotes: "先让孩子说经验。", visualSuggestion: "问题卡" },
        { title: "远方世界", bullets: ["真实案例", "相关职业", "有趣事实"], speakerNotes: "避免堆知识，控制在 5 分钟。", visualSuggestion: "图片或简图" },
        { title: "小组挑战", bullets: ["选材料", "画草图", "动手做", "准备介绍"], speakerNotes: "强调安全和合作。", visualSuggestion: "步骤图" },
        { title: "展示与追问", bullets: ["我发现", "我喜欢", "我建议"], speakerNotes: "不排名，用建设性评价。", visualSuggestion: "三列表格" },
        { title: "我还想知道", bullets: ["写下一个问题", "选出下节课方向"], speakerNotes: "收束兴趣线索。", visualSuggestion: "问题墙" }
      ]
    },
    "no-projector": {
      title: "无投影黑板版 PPT 模板：一块黑板上完兴趣课",
      courseType: "低资源模板",
      ageGroup: "二到六年级",
      durationMinutes: 45,
      localHook: "把 PPT 页面转换成黑板分区、口头故事和任务卡。",
      objectives: ["不用投影也能完成导入", "用黑板组织活动流程", "让学生完成可展示作品"],
      pptOutline: [
        { title: "黑板四区布局", bullets: ["今日问题", "关键词", "小组任务", "展示句式"], speakerNotes: "提前画好四区。", visualSuggestion: "黑板分区图" },
        { title: "口头故事导入", bullets: ["人物", "问题", "办法"], speakerNotes: "3 分钟讲完，孩子复述关键词。", visualSuggestion: "三词提示" },
        { title: "材料替代清单", bullets: ["纸张", "粉笔", "树枝/石子", "绳子/纸条"], speakerNotes: "材料不足允许画图替代。", visualSuggestion: "材料表" },
        { title: "小组任务卡", bullets: ["我们要做什么", "怎么分工", "如何展示"], speakerNotes: "一张纸就是任务卡。", visualSuggestion: "任务卡样式" },
        { title: "课堂收束", bullets: ["我学到", "我还想问", "下次继续"], speakerNotes: "匿名或小组编号即可。", visualSuggestion: "出口卡" }
      ]
    },
    series: {
      title: "四节系列兴趣课 PPT 模板：从启蒙到小展览",
      courseType: "系列课模板",
      ageGroup: "三到六年级",
      durationMinutes: 45,
      localHook: "把一次兴趣启蒙延伸成可交接、可复用的系列课。",
      objectives: ["形成 4 节课结构", "保留学生兴趣线索", "便于下一位志愿者接力"],
      pptOutline: [
        { title: "系列课总览", bullets: ["第 1 课：看见", "第 2 课：动手", "第 3 课：职业", "第 4 课：展览"], speakerNotes: "展示系列结构。", visualSuggestion: "四宫格" },
        { title: "第 1 课：我见过什么", bullets: ["本地观察", "远方案例", "兴趣问题"], speakerNotes: "收集孩子问题。", visualSuggestion: "问题墙" },
        { title: "第 2 课：我能做什么", bullets: ["材料挑战", "小组制作", "改进记录"], speakerNotes: "低成本动手。", visualSuggestion: "制作流程" },
        { title: "第 3 课：谁在做这件事", bullets: ["职业故事", "工具方法", "角色任务"], speakerNotes: "职业启蒙。", visualSuggestion: "职业卡" },
        { title: "第 4 课：我的小展览", bullets: ["作品展示", "同伴反馈", "下一步兴趣"], speakerNotes: "形成可带走的成果。", visualSuggestion: "展览墙" },
        { title: "交接记录", bullets: ["孩子感兴趣的问题", "可复用材料", "下次建议"], speakerNotes: "给后续志愿者使用。", visualSuggestion: "接力表" }
      ]
    }
  };

  const selected = templates[type] || templates.exploration;
  return {
    ...buildOfflineLesson(normalizeInput({ topic: selected.title, courseType: selected.courseType, grade: selected.ageGroup })),
    ...selected,
    materials: [
      { name: "纸", purpose: "任务卡和草图", substitutes: ["旧作业纸", "纸板"], required: true },
      { name: "粉笔", purpose: "黑板分区", substitutes: ["铅笔", "圆珠笔"], required: true },
      { name: "本地材料", purpose: "低成本动手活动", substitutes: ["树枝", "石子", "绳子"], required: false }
    ],
    privacyAndSafety: [
      "模板只给老师备课使用，给孩子使用前需审核。",
      "不要记录学生真实姓名、照片、家庭情况或成绩。",
      "活动评价不做排名，不制造长期奖励循环。"
    ]
  };
}

async function createPptx(lesson, template = "exploration") {
  const templatePath = resolvePptTemplatePath(template);
  if (templatePath) {
    return createPptxFromUserTemplate(lesson, templatePath);
  }

  const pptxgen = resolveOptionalModule("pptxgenjs", true);
  if (!pptxgen) {
    return createMinimalPptx(lesson, template);
  }

  const pptx = new pptxgen();
  pptx.layout = "LAYOUT_WIDE";
  pptx.author = "在地课堂";
  pptx.company = "在地课堂";
  pptx.subject = "支教兴趣课课包";
  pptx.title = lesson.title || "兴趣课课包";
  pptx.lang = "zh-CN";
  pptx.theme = {
    headFontFace: "Microsoft YaHei",
    bodyFontFace: "Microsoft YaHei",
    lang: "zh-CN"
  };

  addTitleSlide(pptx, lesson);
  const outline = asArray(lesson.pptOutline).slice(0, 10);
  for (const slideSpec of outline) addContentSlide(pptx, slideSpec);
  addContentSlide(pptx, {
    title: "黑板替代方案",
    bullets: asArray(lesson.blackboardPlan).slice(0, 6),
    speakerNotes: "没有投影时直接使用这一页的板书结构。",
    visualSuggestion: "黑板四区布局"
  });
  addContentSlide(pptx, {
    title: "隐私与安全",
    bullets: asArray(lesson.privacyAndSafety).slice(0, 6),
    speakerNotes: "现场答辩可强调：AI 只辅助老师，不直接面向孩子。",
    visualSuggestion: "审核清单"
  });

  if (typeof pptx.write === "function") {
    try {
      return await pptx.write({ outputType: "nodebuffer" });
    } catch (_) {
      try {
        return await pptx.write("nodebuffer");
      } catch (error) {
        console.warn(`pptxgenjs 导出失败，切换自包含导出：${error.message}`);
        return createMinimalPptx(lesson, template);
      }
    }
  }
  return createMinimalPptx(lesson, template);
}

function listPptTemplates() {
  return fs.readdirSync(ROOT)
    .filter((name) => name.toLowerCase().endsWith(".pptx"))
    .filter((name) => !name.startsWith("~$"))
    .sort((a, b) => a.localeCompare(b, "zh-CN"))
    .map((name, index) => ({
      id: `template-${index + 1}`,
      name: path.basename(name, ".pptx"),
      filename: name,
      size: fs.statSync(path.join(ROOT, name)).size
    }));
}

function resolvePptTemplatePath(templateId) {
  const template = listPptTemplates().find((item) => item.id === templateId || safeAscii(item.name) === templateId);
  if (!template) return null;
  const templatePath = path.join(ROOT, template.filename);
  if (!templatePath.startsWith(ROOT)) return null;
  return templatePath;
}

function createPptxFromUserTemplate(lesson, templatePath) {
  const entries = readZipEntries(fs.readFileSync(templatePath));
  const slideSpecs = buildTemplateSlides(lesson);
  const slideNames = entries
    .map((entry) => entry.name)
    .filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name))
    .sort((a, b) => Number(a.match(/slide(\d+)/)[1]) - Number(b.match(/slide(\d+)/)[1]));

  const keepSlideCount = Math.min(slideSpecs.length, slideNames.length);
  const keptSlideNames = new Set(slideNames.slice(0, keepSlideCount));
  const removedSlideNames = new Set(slideNames.slice(keepSlideCount));
  const removedRelIds = getRemovedSlideRelIds(entries, removedSlideNames);

  const updatedEntries = entries.filter((entry) => shouldKeepPptxEntry(entry.name, removedSlideNames)).map((entry) => {
    if (entry.name === "docProps/core.xml") {
      return { ...entry, data: xmlBuffer(updateCoreTitle(entry.data.toString("utf8"), lesson.title || "兴趣课课包")) };
    }
    if (entry.name === "[Content_Types].xml") {
      return { ...entry, data: xmlBuffer(removeDeletedSlideContentTypes(entry.data.toString("utf8"), removedSlideNames)) };
    }
    if (entry.name === "ppt/_rels/presentation.xml.rels") {
      return { ...entry, data: xmlBuffer(removeDeletedSlideRelationships(entry.data.toString("utf8"), removedSlideNames)) };
    }
    if (entry.name === "ppt/presentation.xml") {
      return { ...entry, data: xmlBuffer(removeDeletedSlideIds(entry.data.toString("utf8"), removedRelIds)) };
    }
    const slideIndex = slideNames.indexOf(entry.name);
    if (slideIndex >= 0 && keptSlideNames.has(entry.name)) {
      const spec = slideSpecs[slideIndex] || { title: "", bullets: [] };
      return { ...entry, data: xmlBuffer(replaceSlideTexts(entry.data.toString("utf8"), spec)) };
    }
    return entry;
  });

  return makeZip(updatedEntries.map((entry) => ({ name: entry.name, data: entry.data })));
}

function buildTemplateSlides(lesson) {
  const flow = asArray(lesson.flow).slice(0, 5);
  const materials = asArray(lesson.materials).slice(0, 4);
  const activities = asArray(lesson.activities).slice(0, 1);
  const taskCards = asArray(lesson.studentTaskCards).slice(0, 2);
  return [
    {
      title: lesson.title || "兴趣课",
      bullets: [
        `${lesson.ageGroup || ""} · ${lesson.durationMinutes || 45} 分钟`,
        lesson.localHook || "从孩子熟悉的生活经验出发。"
      ]
    },
    {
      title: "课堂目标",
      bullets: asArray(lesson.objectives).slice(0, 4)
    },
    {
      title: "今天怎么上",
      bullets: flow.map((step) => `${step.minutes || ""} ${step.stage || ""}`).filter(Boolean).slice(0, 5)
    },
    {
      title: activities[0] && activities[0].name ? activities[0].name : "小组动手任务",
      bullets: activities[0] ? asArray(activities[0].steps).slice(0, 5) : ["选材料", "画草图", "动手做", "展示介绍"]
    },
    {
      title: "材料与替代",
      bullets: materials.map((item) => {
        const name = item.name || stringifyLessonItem(item);
        const substitutes = asArray(item.substitutes).slice(0, 2).join("、");
        return substitutes ? `${name}：可用${substitutes}替代` : name;
      }).slice(0, 4)
    },
    {
      title: "任务卡",
      bullets: taskCards.length
        ? taskCards.map((card) => `${card.title || "任务"}：${card.instruction || ""}`).slice(0, 4)
        : asArray(lesson.worksheet).map((item) => item.question || stringifyLessonItem(item)).slice(0, 4)
    },
    {
      title: "展示与收束",
      bullets: [
        "每组用一句话介绍作品",
        "同学说一个发现和一个建议",
        ...asArray(lesson.privacyAndSafety).slice(0, 2)
      ].slice(0, 5)
    }
  ].slice(0, 7);
}

function replaceSlideTexts(xml, spec) {
  const replacements = [
    formatPptText(spec.title || "", 34),
    ...asArray(spec.bullets).slice(0, 5).map((item) => formatPptText(item, 42))
  ];
  let index = 0;
  const replaced = xml.replace(/<a:t>([\s\S]*?)<\/a:t>/g, () => {
    const text = replacements[index] || "";
    index += 1;
    return `<a:t>${escapeXml(text)}</a:t>`;
  });
  return normalizeClassroomSlideXml(replaced);
}

function shouldKeepPptxEntry(name, removedSlideNames) {
  if (removedSlideNames.has(name)) return false;
  const relMatch = name.match(/^ppt\/slides\/_rels\/(slide\d+\.xml)\.rels$/);
  if (relMatch && removedSlideNames.has(`ppt/slides/${relMatch[1]}`)) return false;
  return true;
}

function getRemovedSlideRelIds(entries, removedSlideNames) {
  const relEntry = entries.find((entry) => entry.name === "ppt/_rels/presentation.xml.rels");
  if (!relEntry) return new Set();
  const xml = relEntry.data.toString("utf8");
  const ids = new Set();
  for (const slideName of removedSlideNames) {
    const target = slideName.replace("ppt/", "");
    const relationshipPattern = /<Relationship\b[^>]*>/g;
    let match;
    while ((match = relationshipPattern.exec(xml))) {
      const tag = match[0];
      if (!tag.includes(`Target="${target}"`)) continue;
      const idMatch = tag.match(/\bId="([^"]+)"/);
      if (idMatch) ids.add(idMatch[1]);
    }
  }
  return ids;
}

function removeDeletedSlideContentTypes(xml, removedSlideNames) {
  let updated = xml;
  for (const slideName of removedSlideNames) {
    const partName = `/${slideName}`;
    updated = updated.replace(new RegExp(`<Override\\b[^>]*PartName="${escapeRegExp(partName)}"[^>]*/>\\s*`, "g"), "");
  }
  return updated;
}

function removeDeletedSlideRelationships(xml, removedSlideNames) {
  let updated = xml;
  for (const slideName of removedSlideNames) {
    const target = slideName.replace("ppt/", "");
    updated = updated.replace(new RegExp(`<Relationship\\b(?=[^>]*Target="${escapeRegExp(target)}")[^>]*/>\\s*`, "g"), "");
  }
  return updated;
}

function removeDeletedSlideIds(xml, removedRelIds) {
  let updated = xml;
  for (const relId of removedRelIds) {
    updated = updated.replace(new RegExp(`<p:sldId\\b(?=[^>]*r:id="${escapeRegExp(relId)}")[^>]*/>\\s*`, "g"), "");
  }
  return updated;
}

function normalizeClassroomSlideXml(xml) {
  return xml
    .replace(/(<a:rPr\b[^>]*\bsz=")\d+("[^>]*>)/g, "$12000$2")
    .replace(/(<a:rPr\b[^>]*>[\s\S]*?<a:solidFill>\s*<a:srgbClr\s+val=")[0-9A-Fa-f]{6}("[\s\S]*?<\/a:solidFill>)/g, "$1203330$2");
}

function formatPptText(value, maxLength) {
  const text = stringifyLessonItem(value).replace(/\s+/g, " ").trim();
  return text.length > maxLength ? `${text.slice(0, maxLength - 1)}…` : text;
}

function stringifyLessonItem(item) {
  if (item === null || item === undefined) return "";
  if (typeof item === "string") return item;
  if (typeof item === "number") return String(item);
  if (item.text) return item.text;
  if (item.question) return item.question;
  if (item.title && item.instruction) return `${item.title}：${item.instruction}`;
  return Object.values(item).flat().filter(Boolean).join(" ");
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function updateCoreTitle(xml, title) {
  if (xml.includes("<dc:title>")) {
    return xml.replace(/<dc:title>[\s\S]*?<\/dc:title>/, `<dc:title>${escapeXml(title)}</dc:title>`);
  }
  return xml;
}

function readZipEntries(buffer) {
  const eocdOffset = findEndOfCentralDirectory(buffer);
  if (eocdOffset < 0) throw new Error("模板 PPTX 结构异常");
  const entryCount = buffer.readUInt16LE(eocdOffset + 10);
  let centralOffset = buffer.readUInt32LE(eocdOffset + 16);
  const entries = [];

  for (let i = 0; i < entryCount; i += 1) {
    if (buffer.readUInt32LE(centralOffset) !== 0x02014b50) throw new Error("模板 PPTX 中央目录异常");
    const method = buffer.readUInt16LE(centralOffset + 10);
    const compressedSize = buffer.readUInt32LE(centralOffset + 20);
    const filenameLength = buffer.readUInt16LE(centralOffset + 28);
    const extraLength = buffer.readUInt16LE(centralOffset + 30);
    const commentLength = buffer.readUInt16LE(centralOffset + 32);
    const localOffset = buffer.readUInt32LE(centralOffset + 42);
    const name = buffer.slice(centralOffset + 46, centralOffset + 46 + filenameLength).toString("utf8");

    if (buffer.readUInt32LE(localOffset) !== 0x04034b50) throw new Error("模板 PPTX 本地文件头异常");
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const dataOffset = localOffset + 30 + localNameLength + localExtraLength;
    const compressedData = buffer.slice(dataOffset, dataOffset + compressedSize);
    let data;
    if (method === 0) data = compressedData;
    else if (method === 8) data = zlib.inflateRawSync(compressedData);
    else throw new Error(`模板 PPTX 压缩格式不支持：${method}`);

    entries.push({ name, data });
    centralOffset += 46 + filenameLength + extraLength + commentLength;
  }

  return entries;
}

function findEndOfCentralDirectory(buffer) {
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 66000); i -= 1) {
    if (buffer.readUInt32LE(i) === 0x06054b50) return i;
  }
  return -1;
}

function addTitleSlide(pptx, lesson) {
  const slide = pptx.addSlide();
  slide.background = { color: "F7F3E8" };
  slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.33, h: 0.18, fill: { color: "2F6F64" }, line: { color: "2F6F64" } });
  slide.addText(lesson.title || "兴趣课课包", {
    x: 0.75,
    y: 1.15,
    w: 11.8,
    h: 1.0,
    fontFace: "Microsoft YaHei",
    fontSize: 34,
    bold: true,
    color: "1F2D2B",
    margin: 0.02,
    fit: "shrink"
  });
  slide.addText([
    { text: lesson.courseType || "兴趣课", options: { bold: true } },
    { text: `  |  ${lesson.ageGroup || ""}  |  ${lesson.durationMinutes || 45} 分钟` }
  ], {
    x: 0.78,
    y: 2.35,
    w: 11,
    h: 0.35,
    fontFace: "Microsoft YaHei",
    fontSize: 15,
    color: "2F6F64",
    fit: "shrink"
  });
  slide.addText(lesson.localHook || "从孩子熟悉的生活经验出发，打开一节能动手、能分享的兴趣课。", {
    x: 0.8,
    y: 3.1,
    w: 10.9,
    h: 0.9,
    fontFace: "Microsoft YaHei",
    fontSize: 19,
    color: "3E4C49",
    breakLine: false,
    fit: "shrink"
  });
  slide.addText("在地课堂 | 支教兴趣课生成工坊", {
    x: 0.82,
    y: 6.65,
    w: 8,
    h: 0.3,
    fontFace: "Microsoft YaHei",
    fontSize: 11,
    color: "6E7A76"
  });
}

function addContentSlide(pptx, spec) {
  const slide = pptx.addSlide();
  slide.background = { color: "FBFAF5" };
  slide.addText(spec.title || "课堂内容", {
    x: 0.55,
    y: 0.42,
    w: 12.1,
    h: 0.58,
    fontFace: "Microsoft YaHei",
    fontSize: 24,
    bold: true,
    color: "203330",
    margin: 0.02,
    fit: "shrink"
  });
  slide.addShape(pptx.ShapeType.line, {
    x: 0.55,
    y: 1.12,
    w: 12,
    h: 0,
    line: { color: "D7C9A9", width: 1.2 }
  });

  const bullets = asArray(spec.bullets).slice(0, 7);
  slide.addText(bullets.map((item) => `• ${String(item)}`).join("\n"), {
    x: 0.78,
    y: 1.48,
    w: 7.3,
    h: 4.45,
    fontFace: "Microsoft YaHei",
    fontSize: 18,
    color: "263D39",
    breakLine: false,
    fit: "shrink",
    valign: "top",
    margin: 0.04
  });

  slide.addShape(pptx.ShapeType.roundRect, {
    x: 8.55,
    y: 1.55,
    w: 3.9,
    h: 3.25,
    rectRadius: 0.08,
    fill: { color: "E9F0EA" },
    line: { color: "BDD0C4", width: 1 }
  });
  slide.addText(spec.visualSuggestion || "黑板图 / 本地照片 / 材料示意", {
    x: 8.85,
    y: 2.2,
    w: 3.3,
    h: 1.15,
    fontFace: "Microsoft YaHei",
    fontSize: 16,
    color: "31544D",
    bold: true,
    align: "center",
    valign: "mid",
    fit: "shrink"
  });
  if (spec.speakerNotes) {
    slide.addText(`讲解提示：${spec.speakerNotes}`, {
      x: 0.78,
      y: 6.12,
      w: 11.8,
      h: 0.48,
      fontFace: "Microsoft YaHei",
      fontSize: 11,
      color: "63716D",
      fit: "shrink"
    });
  }
}

function createMinimalPptx(lesson, template = "exploration") {
  const theme = getPptTemplateTheme(template);
  const slides = buildMinimalSlides(lesson, template);
  const files = [];
  files.push({
    name: "[Content_Types].xml",
    data: xmlBuffer(contentTypesXml(slides.length))
  });
  files.push({ name: "_rels/.rels", data: xmlBuffer(rootRelsXml()) });
  files.push({ name: "docProps/core.xml", data: xmlBuffer(corePropsXml(lesson.title || "兴趣课课包")) });
  files.push({ name: "docProps/app.xml", data: xmlBuffer(appPropsXml(slides.length)) });
  files.push({ name: "ppt/presentation.xml", data: xmlBuffer(presentationXml(slides.length)) });
  files.push({ name: "ppt/_rels/presentation.xml.rels", data: xmlBuffer(presentationRelsXml(slides.length)) });
  files.push({ name: "ppt/slideMasters/slideMaster1.xml", data: xmlBuffer(slideMasterXml()) });
  files.push({ name: "ppt/slideMasters/_rels/slideMaster1.xml.rels", data: xmlBuffer(slideMasterRelsXml()) });
  files.push({ name: "ppt/slideLayouts/slideLayout1.xml", data: xmlBuffer(slideLayoutXml()) });
  files.push({ name: "ppt/slideLayouts/_rels/slideLayout1.xml.rels", data: xmlBuffer(slideLayoutRelsXml()) });
  files.push({ name: "ppt/theme/theme1.xml", data: xmlBuffer(themeXml()) });

  slides.forEach((slide, index) => {
    const slideNumber = index + 1;
    files.push({
      name: `ppt/slides/slide${slideNumber}.xml`,
      data: xmlBuffer(slideXml(slide, slideNumber, theme))
    });
    files.push({
      name: `ppt/slides/_rels/slide${slideNumber}.xml.rels`,
      data: xmlBuffer(slideRelsXml())
    });
  });

  return makeZip(files);
}

function getPptTemplateTheme(template) {
  const themes = {
    exploration: {
      name: "Interest Explorer",
      bg: "FBFAF5",
      accent: "2F6F64",
      accent2: "D29B45",
      title: "203330",
      body: "263D39",
      panel: "E9F0EA",
      panelLine: "BDD0C4",
      label: "EXPLORE"
    },
    "no-projector": {
      name: "Blackboard",
      bg: "F4F1E6",
      accent: "23443C",
      accent2: "CFAE64",
      title: "172725",
      body: "293B36",
      panel: "E7ECE5",
      panelLine: "9FB6AA",
      label: "BOARD"
    },
    series: {
      name: "Series Course",
      bg: "F6F8FA",
      accent: "315F7C",
      accent2: "B96348",
      title: "172D3A",
      body: "243C4A",
      panel: "E7EEF3",
      panelLine: "A9C0D1",
      label: "SERIES"
    }
  };
  return themes[template] || themes.exploration;
}

function buildMinimalSlides(lesson, template = "exploration") {
  const theme = getPptTemplateTheme(template);
  const outline = asArray(lesson.pptOutline).slice(0, 10);
  const slides = [
    {
      title: lesson.title || "兴趣课课包",
      bullets: [
        `${lesson.courseType || "兴趣课"} | ${lesson.ageGroup || ""} | ${lesson.durationMinutes || 45} 分钟`,
        lesson.localHook || "从孩子熟悉的生活经验出发。",
        "先观察，再动手，再分享。"
      ],
      note: "在地课堂"
    },
    ...outline.map((item) => ({
      title: item.title || "课堂内容",
      bullets: asArray(item.bullets).slice(0, 6),
      note: item.speakerNotes || item.visualSuggestion || ""
    })),
    {
      title: "黑板替代方案",
      bullets: asArray(lesson.blackboardPlan).slice(0, 6),
      note: "没有投影时使用"
    },
    {
      title: "隐私与安全",
      bullets: asArray(lesson.privacyAndSafety).slice(0, 6),
      note: "AI 内容先由老师审核"
    }
  ];
  return slides.slice(0, 14);
}

function contentTypesXml(slideCount) {
  const slideOverrides = Array.from({ length: slideCount }, (_, index) => {
    const number = index + 1;
    return `<Override PartName="/ppt/slides/slide${number}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`;
  }).join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  <Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>
  <Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>
  <Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  ${slideOverrides}
</Types>`;
}

function rootRelsXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`;
}

function corePropsXml(title) {
  const now = new Date().toISOString();
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>${escapeXml(title)}</dc:title>
  <dc:creator>在地课堂</dc:creator>
  <cp:lastModifiedBy>在地课堂</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified>
</cp:coreProperties>`;
}

function appPropsXml(slideCount) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>在地课堂</Application>
  <PresentationFormat>宽屏</PresentationFormat>
  <Slides>${slideCount}</Slides>
  <Company>在地课堂</Company>
</Properties>`;
}

function presentationXml(slideCount) {
  const slideIds = Array.from({ length: slideCount }, (_, index) => {
    const number = index + 1;
    return `<p:sldId id="${255 + number}" r:id="rId${number + 1}"/>`;
  }).join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>
  <p:sldIdLst>${slideIds}</p:sldIdLst>
  <p:sldSz cx="12192000" cy="6858000" type="wide"/>
  <p:notesSz cx="6858000" cy="9144000"/>
</p:presentation>`;
}

function presentationRelsXml(slideCount) {
  const slideRels = Array.from({ length: slideCount }, (_, index) => {
    const number = index + 1;
    return `<Relationship Id="rId${number + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${number}.xml"/>`;
  }).join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>
  ${slideRels}
</Relationships>`;
}

function slideMasterXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld><p:spTree>${groupShapeXml()}</p:spTree></p:cSld>
  <p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>
  <p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>
  <p:txStyles>
    <p:titleStyle/><p:bodyStyle/><p:otherStyle/>
  </p:txStyles>
</p:sldMaster>`;
}

function slideMasterRelsXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>
</Relationships>`;
}

function slideLayoutXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1">
  <p:cSld name="Blank"><p:spTree>${groupShapeXml()}</p:spTree></p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sldLayout>`;
}

function slideLayoutRelsXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>
</Relationships>`;
}

function slideRelsXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>
</Relationships>`;
}

function themeXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Zaidi">
  <a:themeElements>
    <a:clrScheme name="Zaidi">
      <a:dk1><a:srgbClr val="203330"/></a:dk1>
      <a:lt1><a:srgbClr val="FBFAF5"/></a:lt1>
      <a:dk2><a:srgbClr val="2F6F64"/></a:dk2>
      <a:lt2><a:srgbClr val="EEF3EF"/></a:lt2>
      <a:accent1><a:srgbClr val="2F6F64"/></a:accent1>
      <a:accent2><a:srgbClr val="D29B45"/></a:accent2>
      <a:accent3><a:srgbClr val="B96348"/></a:accent3>
      <a:accent4><a:srgbClr val="496F91"/></a:accent4>
      <a:accent5><a:srgbClr val="8CA987"/></a:accent5>
      <a:accent6><a:srgbClr val="D7C9A9"/></a:accent6>
      <a:hlink><a:srgbClr val="496F91"/></a:hlink>
      <a:folHlink><a:srgbClr val="6A4F7A"/></a:folHlink>
    </a:clrScheme>
    <a:fontScheme name="Zaidi"><a:majorFont><a:latin typeface="Microsoft YaHei"/><a:ea typeface="Microsoft YaHei"/></a:majorFont><a:minorFont><a:latin typeface="Microsoft YaHei"/><a:ea typeface="Microsoft YaHei"/></a:minorFont></a:fontScheme>
    <a:fmtScheme name="Zaidi"><a:fillStyleLst/><a:lnStyleLst/><a:effectStyleLst/><a:bgFillStyleLst/></a:fmtScheme>
  </a:themeElements>
</a:theme>`;
}

function slideXml(slide, index, theme = getPptTemplateTheme("exploration")) {
  const title = truncateText(slide.title || "课堂内容", 42);
  const bullets = asArray(slide.bullets).slice(0, 7).map((item) => truncateText(String(item), 58));
  const note = truncateText(slide.note || "", 75);
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld>
    <p:bg><p:bgPr><a:solidFill><a:srgbClr val="${theme.bg}"/></a:solidFill></p:bgPr></p:bg>
    <p:spTree>
      ${groupShapeXml()}
      ${decorativeBarXml(20, theme.accent)}
      ${textShapeXml(2, "Title", 640000, 430000, 11000000, 760000, title, 3000, theme.title, true)}
      ${textShapeXml(3, "Bullets", 820000, 1450000, 7800000, 4100000, bullets.map((item) => `• ${item}`).join("\n"), 1850, "263D39", false)}
      ${shapeXml(4, 8800000, 1530000, 3300000, 2600000, theme.panel, theme.panelLine)}
      ${textShapeXml(5, "Visual", 9100000, 2100000, 2700000, 850000, "在地课堂\\n${index}", 2200, "2F6F64", true, "ctr")}
      ${note ? textShapeXml(6, "Note", 820000, 6060000, 11000000, 420000, `讲解提示：${note}`, 1050, "63716D", false) : ""}
    </p:spTree>
  </p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sld>`;
}

function groupShapeXml() {
  return `<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>`;
}

function decorativeBarXml(id, color) {
  return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Template Bar"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="12192000" cy="120000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p/></p:txBody></p:sp>`;
}

function shapeXml(id, x, y, w, h, fill = "E9F0EA", line = "BDD0C4") {
  return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Panel"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/></a:xfrm><a:prstGeom prst="roundRect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="${fill}"/></a:solidFill><a:ln><a:solidFill><a:srgbClr val="${line}"/></a:solidFill></a:ln></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p/></p:txBody></p:sp>`;
}

function textShapeXml(id, name, x, y, w, h, text, fontSize, color, bold, align = "l") {
  const lines = String(text || "").split(/\n/);
  const paragraphs = lines.map((line) => {
    return `<a:p><a:pPr algn="${align}"/><a:r><a:rPr lang="zh-CN" sz="${fontSize}"${bold ? ' b="1"' : ""}><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="Microsoft YaHei"/><a:ea typeface="Microsoft YaHei"/></a:rPr><a:t>${escapeXml(line)}</a:t></a:r><a:endParaRPr lang="zh-CN" sz="${fontSize}"/></a:p>`;
  }).join("");

  return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${escapeXml(name)}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${w}" cy="${h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square" anchor="top"><a:spAutoFit/></a:bodyPr><a:lstStyle/>${paragraphs}</p:txBody></p:sp>`;
}

function xmlBuffer(xml) {
  return Buffer.from(xml, "utf8");
}

function escapeXml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function truncateText(value, max) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function makeZip(files) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;
  const { time, date } = dosDateTime(new Date());

  for (const file of files) {
    const nameBuffer = Buffer.from(file.name, "utf8");
    const data = Buffer.isBuffer(file.data) ? file.data : Buffer.from(file.data);
    const crc = crc32(data);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuffer.length, 26);
    local.writeUInt16LE(0, 28);
    localParts.push(local, nameBuffer, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(time, 12);
    central.writeUInt16LE(date, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(nameBuffer.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centralParts.push(central, nameBuffer);

    offset += local.length + nameBuffer.length + data.length;
  }

  const centralDirectory = Buffer.concat(centralParts);
  const localData = Buffer.concat(localParts);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralDirectory.length, 12);
  end.writeUInt32LE(localData.length, 16);
  end.writeUInt16LE(0, 20);

  return Buffer.concat([localData, centralDirectory, end]);
}

function dosDateTime(dateObj) {
  const year = Math.max(1980, dateObj.getFullYear());
  const month = dateObj.getMonth() + 1;
  const day = dateObj.getDate();
  const hours = dateObj.getHours();
  const minutes = dateObj.getMinutes();
  const seconds = Math.floor(dateObj.getSeconds() / 2);
  return {
    time: (hours << 11) | (minutes << 5) | seconds,
    date: ((year - 1980) << 9) | (month << 5) | day
  };
}

function crc32(buffer) {
  let crc = 0xffffffff;
  for (let i = 0; i < buffer.length; i += 1) {
    crc ^= buffer[i];
    for (let j = 0; j < 8; j += 1) {
      crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function resolveOptionalModule(name, silent = false) {
  const candidates = [
    name,
    process.env.NODE_PATH ? path.join(process.env.NODE_PATH, name) : null,
    path.join(os.homedir(), ".cache", "codex-runtimes", "codex-primary-runtime", "dependencies", "node", "node_modules", name)
  ].filter(Boolean);

  for (const candidate of candidates) {
    try {
      return require(candidate);
    } catch (_) {
      // Try the next location.
    }
  }
  if (!silent) console.warn(`Optional module not found: ${name}`);
  return null;
}

function asArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value.filter((item) => item !== undefined && item !== null && String(item).trim() !== "");
  if (typeof value === "string") {
    return value
      .split(/[，,、\n]/)
      .map((item) => item.trim())
      .filter(Boolean);
  }
  return [value];
}

function pickLocalThing(text) {
  const candidates = ["菜地", "操场", "小路", "山坡", "河流", "集市", "村庄建筑", "校门口"];
  return candidates.find((item) => text.includes(item)) || "身边环境";
}

function buildSubstitutes(name) {
  const map = {
    纸: ["旧作业纸", "纸板", "包装纸"],
    铅笔: ["粉笔", "圆珠笔"],
    树枝: ["筷子", "吸管", "纸卷"],
    石子: ["豆子", "瓶盖", "纸团"],
    绳子: ["毛线", "纸条", "鞋带"],
    彩笔: ["铅笔标注", "粉笔"],
    纸杯: ["塑料瓶", "纸筒"],
    塑料瓶: ["纸杯", "纸筒"]
  };
  return map[name] || ["纸", "粉笔", "本地可获得材料"];
}

function safeFilename(name) {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\s+/g, "-")
    .slice(0, 80) || "zaidi-lesson";
}

function safeAscii(value) {
  return String(value || "template")
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 50) || "template";
}
